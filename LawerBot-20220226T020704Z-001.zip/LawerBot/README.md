Mã hóa fbstate cho replit thường tránh bị check acc

#xem video hướng dẫn: https://i.imgur.com/uHsd2RZ.mp4
#
"encryptSt": true

key: KEY

value: một dãy kí tự tùy ý
